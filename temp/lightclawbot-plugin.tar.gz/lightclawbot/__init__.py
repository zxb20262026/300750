"""
lightclawbot — LightClaw platform plugin for Hermes Agent.

Registers the LightClaw adapter via the Hermes plugin discovery system.
No source-code modifications to lighthouse-hermes are required — the adapter
is discovered automatically when this package is placed under
``~/.hermes/plugins/lightclawbot/`` or installed via pip (entry_points).
"""

import os


def _get_version() -> str:
    """Return package version from importlib.metadata, with fallback."""
    try:
        from importlib.metadata import version

        return version("lightclawbot")
    except Exception:
        return "0.0.0"


__version__ = _get_version()


def _load_platform_hint() -> str:
    """Return the LightClaw-specific LLM capability hint.

    Only contents that are *unique* to LightClaw belong here.  The generic
    ``MEDIA:/absolute/path/to/file`` protocol, supported extensions and
    text post-processing are owned by the framework
    (``BasePlatformAdapter.extract_media`` + ``PLATFORM_HINTS`` in
    ``agent/prompt_builder.py``) and are intentionally NOT re-stated here.
    """
    return (
        "You are on LightClaw, a WebSocket-based messaging platform. "
        "Markdown formatting is supported (code blocks, bold, italic, tables). "
        "You can send files natively by including MEDIA:/absolute/path/to/file "
        "in your reply; the file is delivered to the user as an on-demand "
        "download link (no need to upload or build https URLs yourself). "
        "For cron jobs / reminders / scheduled tasks, always set "
        "deliver='lightclawbot:<chat_id>' so results reach the user instead of "
        "being saved locally."
    )


def _validate_config(config) -> bool:
    """Check whether the platform config has enough info to connect."""
    extra = getattr(config, "extra", {}) or {}
    return bool(extra.get("api_keys") or os.getenv("LIGHTCLAW_API_KEY", ""))


def _is_connected(config) -> bool:
    """Check whether the platform is sufficiently configured (for status display)."""
    extra = getattr(config, "extra", {}) or {}
    return bool(extra.get("api_keys"))


def register(ctx):
    """Called by the Hermes plugin discovery system.

    Registers the LightClaw platform adapter so that:
      - Platform("lightclawbot") resolves to a dynamic enum member
      - The gateway creates and connects a LightClawAdapter at startup
      - send_message routes to the adapter via _send_via_adapter()
      - Cron delivery to "lightclawbot:<chat_id>" works automatically
      - User authorization respects LIGHTCLAW_ALLOWED_USERS env var
    """
    from .src import LightClawAdapter, check_lightclaw_requirements

    ctx.register_platform(
        name="lightclawbot",
        label="LightClawBot",
        adapter_factory=lambda cfg: LightClawAdapter(cfg),
        check_fn=check_lightclaw_requirements,
        validate_config=_validate_config,
        is_connected=_is_connected,
        required_env=["LIGHTCLAW_API_KEY"],
        install_hint="See https://pypi.org/project/lightclawbot/",
        allowed_users_env="LIGHTCLAW_ALLOWED_USERS",
        allow_all_env="LIGHTCLAW_ALLOW_ALL_USERS",
        max_message_length=4096,
        emoji="⚡",
        platform_hint=_load_platform_hint(),
    )


__all__ = ["register", "__version__"]
